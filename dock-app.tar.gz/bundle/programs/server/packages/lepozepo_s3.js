(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;

/* Package-scope variables */
var Knox, AWS, __coffeescriptShare;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo:s3/server/startup.coffee.js                                                           //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
              

Knox = Npm.require("knox");

AWS = Npm.require("aws-sdk");

this.S3 = {
  config: {},
  knox: {},
  aws: {}
};

Meteor.startup(function() {
  if (!_.has(S3.config, "key")) {
    console.log("S3: AWS key is undefined");
  }
  if (!_.has(S3.config, "secret")) {
    console.log("S3: AWS secret is undefined");
  }
  if (!_.has(S3.config, "bucket")) {
    console.log("S3: AWS bucket is undefined");
  }
  if (!_.has(S3.config, "bucket") || !_.has(S3.config, "secret") || !_.has(S3.config, "key")) {
    return;
  }
  _.defaults(S3.config, {
    region: "us-east-1"
  });
  S3.knox = Knox.createClient(S3.config);
  return S3.aws = new AWS.S3({
    accessKeyId: S3.config.key,
    secretAccessKey: S3.config.secret,
    region: S3.config.region
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo:s3/server/sign_request.coffee.js                                                      //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculate_signature, crypto;

Meteor.methods({
  _s3_sign: function(ops) {
    var expiration, key, policy, post_url, signature;
    if (ops == null) {
      ops = {};
    }
    this.unblock();
    check(ops, Object);
    _.defaults(ops, {
      expiration: 1800000,
      path: "",
      bucket: S3.config.bucket,
      acl: "public-read",
      region: S3.config.region
    });
    expiration = new Date(Date.now() + ops.expiration);
    expiration = expiration.toISOString();
    key = "" + ops.path + "/" + ops.file_name;
    policy = {
      "expiration": expiration,
      "conditions": [
        ["content-length-range", 0, ops.file_size], {
          "key": key
        }, {
          "bucket": ops.bucket
        }, {
          "Content-Type": ops.file_type
        }, {
          "acl": ops.acl
        }, {
          "Content-Disposition": "inline; filename='" + ops.file_name + "'"
        }
      ]
    };
    policy = Buffer(JSON.stringify(policy), "utf-8").toString("base64");
    signature = calculate_signature(policy);
    if (ops.region === "us-east-1" || ops.region === "us-standard") {
      post_url = "https://" + ops.bucket + ".s3.amazonaws.com";
    } else {
      post_url = "https://" + ops.bucket + ".s3-" + ops.region + ".amazonaws.com";
    }
    return {
      policy: policy,
      signature: signature,
      access_key: S3.config.key,
      post_url: post_url,
      url: ("" + post_url + "/" + key).replace("https://", "http://"),
      secure_url: "" + post_url + "/" + key,
      relative_url: "/" + key,
      bucket: ops.bucket,
      acl: ops.acl,
      key: key,
      file_type: ops.file_type,
      file_name: ops.file_name
    };
  }
});

crypto = Npm.require("crypto");

calculate_signature = function(policy) {
  return crypto.createHmac("sha1", S3.config.secret).update(new Buffer(policy, "utf-8")).digest("base64");
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo:s3/server/delete_object.coffee.js                                                     //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Future;

Future = Npm.require('fibers/future');

Meteor.methods({
  _s3_delete: function(path) {
    var future;
    this.unblock();
    check(path, String);
    future = new Future();
    S3.knox.deleteFile(path, function(e, r) {
      if (e) {
        console.log(e);
        return future["return"](e);
      } else {
        return future["return"](true);
      }
    });
    return future.wait();
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['lepozepo:s3'] = {
  Knox: Knox,
  AWS: AWS
};

})();

//# sourceMappingURL=lepozepo_s3.js.map
