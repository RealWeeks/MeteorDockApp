(function(){Comments = new Mongo.Collection('comments');
// collections > docs > map <--path in console to inspect

ChatRooms = new Mongo.Collection("chatrooms");

})();
