(function(){S3.config = {
    key: 'AKIAJXOSUJOZDJMEW22Q',
    secret: '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',
    bucket: 'jweeks'
};

})();
